import React, { Component } from 'react'

class Checkout extends Component {
    render() {
        return (
            <div>
                <h1>Checkout</h1>
            </div>
        )
    }
}

export default Checkout;
