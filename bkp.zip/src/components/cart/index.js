import React, { Component } from 'react'
import { Card, Button } from "react-bootstrap";

class Cart extends Component {
    render() {
        return (
            <Card>
                <Card.Header as="h5">Product 1</Card.Header>
                <Card.Body>
                    <Card.Title>Price : Rs 100</Card.Title>
                    <Card.Text>
                        With supporting text below as a natural lead-in to additional content.
                    </Card.Text>
                </Card.Body>
            </Card>
        )
    }
}
export default Cart;