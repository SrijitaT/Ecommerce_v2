import React, { Component } from 'react'

export default class Nomatch extends Component {
    render() {
        return (
            <div>
                404 not found
            </div>
        )
    }
}
