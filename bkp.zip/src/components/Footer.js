import React from 'react';
import "../App.css";

function Footer() {
    return (
        <footer className="footer">
            Footer goes here
        </footer>
    )
}
export default Footer;