import React, { Component } from 'react'
import Product from "./index";
import { Row, Col } from "react-bootstrap";
class Catalogue extends Component {
    render() {
        const items = [0, 0, 0, 0, 0, 0];
        return (
            <div>
                <Col>
                    <Row>
                        {
                            items.map((x, index) => <Product index={index} />)
                        }
                    </Row>
                </Col>
            </div>
        )
    }
}
export default Catalogue;
