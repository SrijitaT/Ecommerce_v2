import React, { Component } from 'react'
import { Card, Button } from "react-bootstrap";

class Product extends Component {
    render() {
        const { index } = this.props;
        return (
            <Card>
                <Card.Header as="h5">Featured</Card.Header>
                <Card.Body>
                    <Card.Title>Product {index + 1}</Card.Title>
                    <Card.Text>
                        With supporting text below as a natural lead-in to additional content.
                    </Card.Text>
                    <Button variant="success">Add to cart</Button>{"  "}
                    <Button variant="warning" href={`/desc/${index + 1}`}>View Details</Button>
                </Card.Body>
            </Card>
        )
    }
}
export default Product;
